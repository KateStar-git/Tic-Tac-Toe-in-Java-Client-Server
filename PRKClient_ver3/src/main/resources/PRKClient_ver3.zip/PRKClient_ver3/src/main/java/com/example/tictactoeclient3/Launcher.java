package com.example.tictactoeclient3;

/**
 * Klasa pomocnicza uruchamiaj�ca gr�
 */
public class Launcher {
    public static void main(String[] args){
        TicTacToeApplication.main(args);
    }
}
